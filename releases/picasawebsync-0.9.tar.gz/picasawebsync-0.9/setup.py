from distutils.core import setup
setup(name='picasawebsync',
      version='0.9',
      py_modules=['picasawebsync'],
      scripts=['picasawebsync.py']
      )
