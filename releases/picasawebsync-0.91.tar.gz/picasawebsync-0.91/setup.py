from distutils.core import setup
setup(name='picasawebsync',
      version='0.91',
      py_modules=['picasawebsync'],
      scripts=['picasawebsync.py']
      )
